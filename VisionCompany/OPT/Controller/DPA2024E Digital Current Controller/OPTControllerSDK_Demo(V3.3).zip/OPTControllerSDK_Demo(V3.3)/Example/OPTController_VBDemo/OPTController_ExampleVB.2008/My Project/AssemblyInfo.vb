﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("OPTController_ExampleVB.2008.exe")> 
<Assembly: AssemblyDescription("Application Program")> 
<Assembly: AssemblyCompany("OPT MACHINE VISION TECH CO.,LTD.")> 
<Assembly: AssemblyProduct("OPTController_ExampleVB.2008.exe")> 
<Assembly: AssemblyCopyright("Copyright (C), 2005 OPT MACHINE VISION TECH CO.,LTD. All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("cb0591f8-7c29-484a-883a-57a7fd29d8e0")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.6.0")> 
<Assembly: AssemblyFileVersion("1.0.6.0")> 
